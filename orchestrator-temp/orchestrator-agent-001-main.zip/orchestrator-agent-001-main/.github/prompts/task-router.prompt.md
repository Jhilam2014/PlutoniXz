Read AGENTS.md and ROOT_WORKSPACE_GENERATION_POLICY.md fully.

The user may provide only:

```text
Task type: tiny | small | medium | large
Task: <task description>
```

Automatically load the matching GitHub Copilot task prompt:

- tiny -> `.github/prompts/task-small.prompt.md`
- small -> `.github/prompts/task-small.prompt.md`
- medium -> `.github/prompts/task-medium.prompt.md`
- large -> `.github/prompts/task-large.prompt.md`

Apply the selected prompt completely.

Do not ask the user to paste the full prompt.

If the prompt file is missing, stop and report the missing path.

After loading the prompt, execute the task according to:

1. AGENTS.md
2. ROOT_WORKSPACE_GENERATION_POLICY.md
3. selected GitHub Copilot task prompt
4. user task

Do not modify AGENTS.md unless the user explicitly says to modify the canonical orchestrator instruction.
