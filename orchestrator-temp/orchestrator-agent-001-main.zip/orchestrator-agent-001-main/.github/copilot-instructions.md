# GitHub Copilot instructions for Agentic BuilderX

The canonical orchestrator instruction is `AGENTS.md`.

Do not duplicate, override, or weaken `AGENTS.md`. If this file conflicts with `AGENTS.md`, `AGENTS.md` wins.

Before implementing a task, read:

1. `AGENTS.md`
2. `ROOT_WORKSPACE_GENERATION_POLICY.md`
3. the selected prompt file from `.github/prompts/`
4. the user task

When the user provides:

```text
Task type: tiny | small | medium | large
Task: <task description>
```

Use `.github/prompts/task-router.prompt.md`, then load:

- tiny -> `.github/prompts/task-small.prompt.md`
- small -> `.github/prompts/task-small.prompt.md`
- medium -> `.github/prompts/task-medium.prompt.md`
- large -> `.github/prompts/task-large.prompt.md`

Rules:

1. Preserve existing behavior unless the user explicitly requests a change.
2. Do not silently skip mandatory orchestrator artifacts required by `AGENTS.md`.
3. Do not invent command results, test results, Neo4j sync, vector sync, or deployment status.
4. If credentials are missing, generate local artifacts and mark sync pending.
5. If vector DB is missing, follow the ChromaDB fallback behavior defined in `AGENTS.md`.
6. Follow `ROOT_WORKSPACE_GENERATION_POLICY.md` for generated artifacts.
7. Use concise reports for tiny/small tasks.
8. Use structured plans for medium/large tasks.
