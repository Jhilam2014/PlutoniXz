Read CLAUDE.md, AGENTS.md, and ROOT_WORKSPACE_GENERATION_POLICY.md fully.

The user may provide only:

```text
Task type: tiny | small | medium | large
Task: <task description>
```

Automatically load the matching Claude task template:

- tiny -> `.claude/prompts/task-small.md`
- small -> `.claude/prompts/task-small.md`
- medium -> `.claude/prompts/task-medium.md`
- large -> `.claude/prompts/task-large.md`

Apply the selected template completely.

Do not ask the user to paste the full template.

If the Claude template file is missing, stop and report the missing path.

After loading the template, execute the task according to:

1. AGENTS.md
2. ROOT_WORKSPACE_GENERATION_POLICY.md
3. selected Claude task template
4. user task

Do not modify AGENTS.md unless the user explicitly says to modify the canonical orchestrator instruction.
