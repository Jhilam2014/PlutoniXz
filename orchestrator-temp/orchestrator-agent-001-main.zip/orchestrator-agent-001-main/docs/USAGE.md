# Usage

## New project

Copy this package into the project root.

Your project root should contain:

```text
AGENTS.md
CLAUDE.md
ROOT_WORKSPACE_GENERATION_POLICY.md
.env.example
.codex/prompts/
.claude/settings.example.json
```

## Bootstrap

Run once when you want the orchestrator infrastructure created:

```text
Use .codex/prompts/bootstrap-orchestrator.md and execute the bootstrap.
```

## Normal task

```text
Task type: small
Task: Fix the hero headline so it is fully visible above the fold.
```

## Important

You do not need to write:

```text
Rules:
Validation:
After completion, report:
```

Those are already in the task templates.

Do not modify `AGENTS.md` unless you intentionally want to change the canonical orchestrator instruction.
